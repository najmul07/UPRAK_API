﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Uprak.Migrations
{
    public partial class tes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tb_kendaraan",
                columns: table => new
                {
                    plat_nomer = table.Column<string>(type: "varchar(200)", nullable: false),
                    jenis_kendaraan = table.Column<string>(type: "varchar(200)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tb_kendaraan", x => x.plat_nomer);
                });

            migrationBuilder.CreateTable(
                name: "tb_petugas",
                columns: table => new
                {
                    id_petugas = table.Column<string>(type: "varchar(200)", nullable: false),
                    nama = table.Column<string>(type: "varchar(200)", nullable: true),
                    alamat = table.Column<string>(type: "varchar(200)", nullable: true),
                    password = table.Column<string>(type: "varchar(200)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tb_petugas", x => x.id_petugas);
                });

            migrationBuilder.CreateTable(
                name: "tb_transaksi",
                columns: table => new
                {
                    id_parkir = table.Column<string>(type: "varchar(200)", nullable: false),
                    plat_nomer = table.Column<string>(type: "varchar(200)", nullable: true),
                    id_petugas = table.Column<string>(type: "varchar(200)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tb_transaksi", x => x.id_parkir);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tb_kendaraan");

            migrationBuilder.DropTable(
                name: "tb_petugas");

            migrationBuilder.DropTable(
                name: "tb_transaksi");
        }
    }
}
