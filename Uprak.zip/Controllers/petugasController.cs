using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Uprak.Models;

namespace Uprak.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class petugasController : ControllerBase
    {
        private readonly ParkingContext _context;

        public petugasController(ParkingContext context)
        {
            _context = context;
        }

        // GET: api/petugas
        [HttpGet]
        public async Task<ActionResult<IEnumerable<petugas>>> Gettb_petugas()
        {
            return await _context.tb_petugas.ToListAsync();
        }

        // GET: api/petugas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<petugas>> Getpetugas(string id)
        {
            var petugas = await _context.tb_petugas.FindAsync(id);

            if (petugas == null)
            {
                return NotFound();
            }

            return petugas;
        }

        // PUT: api/petugas/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Putpetugas(string id, petugas petugas)
        {
            if (id != petugas.id_petugas)
            {
                return BadRequest();
            }

            _context.Entry(petugas).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!petugasExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/petugas
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<petugas>> Postpetugas(petugas petugas)
        {
            _context.tb_petugas.Add(petugas);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (petugasExists(petugas.id_petugas))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("Getpetugas", new { id = petugas.id_petugas }, petugas);
        }

        // DELETE: api/petugas/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Deletepetugas(string id)
        {
            var petugas = await _context.tb_petugas.FindAsync(id);
            if (petugas == null)
            {
                return NotFound();
            }

            _context.tb_petugas.Remove(petugas);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool petugasExists(string id)
        {
            return _context.tb_petugas.Any(e => e.id_petugas == id);
        }
    }
}
