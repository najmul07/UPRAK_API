using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Uprak.Models
{
    public class kendaraan
    {
        [Key]
        [Column(TypeName ="varchar(200)")]
        public string plat_nomer { get; set; }

        [Column(TypeName ="varchar(200)")]
        public string jenis_kendaraan { get; set; }
    }
}