using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace Uprak.Models
{
    public class petugas
    {
        [Key]
        [Column(TypeName ="varchar(200)")]
        public string id_petugas { get; set; }
        [Column(TypeName ="varchar(200)")]
        public string nama { get; set; }
        [Column(TypeName ="varchar(200)")]
        public string alamat { get; set; }
        [Column(TypeName ="varchar(200)")]
        public string password { get; set; }

        // [ForeignKey("id_petugas")]
        // public ICollection <transaksi> Transaksis { get; set; }  
    }
}