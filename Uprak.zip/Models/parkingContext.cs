using Microsoft.EntityFrameworkCore;
using System.Diagnostics.CodeAnalysis;

namespace Uprak.Models
{
    public class ParkingContext : DbContext
    {
        public ParkingContext(DbContextOptions<ParkingContext> options)
            : base(options)
        {
        }

        public DbSet<kendaraan> tb_kendaraan { get; set; } = null!;
        public DbSet<petugas> tb_petugas { get; set; } = null!;
        public DbSet<transaksi> tb_transaksi { get; set; } = null!;
    }
}