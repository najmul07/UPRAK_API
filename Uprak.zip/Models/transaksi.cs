using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Uprak.Models
{
    public class transaksi
    {
        [Key]
        [Column(TypeName ="varchar(200)")]
        public string id_parkir { get; set; }

        [Column(TypeName ="varchar(200)")]
        public string plat_nomer { get; set; }

        [Column(TypeName ="varchar(200)")]
        public string id_petugas { get; set; }

        // [ForeignKey("plat_nomer")]
        // public ICollection <kendaraan> kendaraans { get; set; }

    }
}